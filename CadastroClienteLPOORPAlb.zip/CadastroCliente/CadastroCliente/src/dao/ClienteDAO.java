package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import models.Cliente;
/**
 *
 * @author Rafael
 */

public class ClienteDAO {
    
    private List<Cliente> clientes = new ArrayList<Cliente>();
    
    public void inserirCliente(Cliente cli){
        
        
        Connection con = Conexao.criarConexao();
        PreparedStatement stmt = null;
                
        try {
            stmt = con.prepareStatement("INSERT INTO cliente (codigo, nome, telefone, nascimento) VALUES (?,?,?,?)");
            stmt.setInt(1, cli.getCodigo());
            stmt.setString(2, cli.getNome());
            stmt.setString(3, cli.getTelefone());
            stmt.setTimestamp(4, new java.sql.Timestamp(cli.getNascimento().getTime()));

            stmt.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "Cliente inserido!");        
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro: "+ex);
        }
    }
    
    public void update(Cliente cli){
        
        Connection con = Conexao.criarConexao();
        PreparedStatement stmt = null;
        
        try {
            stmt = con.prepareStatement("UPDATE cliente SET codigo = ?,nome = ?,telefone = ?,nascimento = ? WHERE codigo = ?");
            stmt.setInt(1, cli.getCodigo());
            stmt.setString(2, cli.getNome());
            stmt.setString(3, cli.getTelefone());
            stmt.setTimestamp(4, new java.sql.Timestamp(cli.getNascimento().getTime()));
            stmt.setInt(5, cli.getCodigo());

            stmt.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "Cliente atualizado!");        
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro: "+ex);
        }
    }
    
    public void delete(Cliente cli){
        Connection con = Conexao.criarConexao();
        PreparedStatement stmt = null;
        
        try {
            stmt = con.prepareStatement("DELETE FROM cliente WHERE codigo = ?");
            stmt.setInt(1,cli.getCodigo());

            stmt.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "Cliente excluído!");        
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro: "+ex);
        } finally {
            Conexao.closeConnection(con, stmt);
        }
        
    }
    
    
   public List<Cliente> read(){
        
        Connection con = Conexao.criarConexao();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        List<Cliente> cliList = new ArrayList<>();
        
        try {
            stmt = con.prepareStatement("SELECT * FROM cliente");
            rs = stmt.executeQuery();
            
            while (rs.next()) {
                
                Cliente cli = new Cliente();
                
                cli.setCodigo(rs.getInt("codigo"));
                cli.setNome(rs.getString("nome"));
                cli.setTelefone(rs.getString("telefone"));
                cli.setNascimento(rs.getDate("nascimento"));
                
                cliList.add(cli);
                
            }
          
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro na Consulta: "+ex);
        } finally {
            Conexao.closeConnection(con, stmt, rs);
        }
        
        return cliList;
    }
    
    
}