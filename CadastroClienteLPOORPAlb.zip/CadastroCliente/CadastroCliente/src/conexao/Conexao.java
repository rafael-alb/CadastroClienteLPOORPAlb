package conexao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Rafael
 */

public class Conexao {   
    public static Connection criarConexao() {
        final String DRIVER = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
        final String DATABASE_URL = "jdbc:sqlserver://localhost:1433;databaseName=JDBC;user=javassim;password=123456";
        Connection connection = null;
         try {
        Class.forName(DRIVER);
        connection = DriverManager.getConnection(DATABASE_URL);
                
        } catch (SQLException|ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
        }
         return connection;
    }
    
    public static void closeConnection(Connection con){
        
       try {
           if(con != null){
               con.close();
           }
       } catch (SQLException ex){
           Logger.getLogger(Conexao.class.getName()).log(Level.SEVERE, null, ex);
       }
    }
    
    public static void closeConnection(Connection con, PreparedStatement stmt){
        
       closeConnection(con);
       
        try {
           if(stmt != null){
               stmt.close();
           }
       } catch (SQLException ex){
           Logger.getLogger(Conexao.class.getName()).log(Level.SEVERE, null, ex);
       }
    }
    
    public static void closeConnection(Connection con, PreparedStatement stmt, ResultSet rs){
        
       closeConnection(con, stmt);
       
        try {
           if(rs != null){
               rs.close();
           }
       } catch (SQLException ex){
           Logger.getLogger(Conexao.class.getName()).log(Level.SEVERE, null, ex);
       }
    }
    //construtor
    public Conexao() {

    }
}

