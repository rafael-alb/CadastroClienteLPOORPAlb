/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

import java.util.Date;

/**
 *
 * @author Stefano
 */
public class Cliente {

    /**
     * @param codigo
     * @return the codigo
     */
    
//    public Cliente(Integer codigo,String nome, Integer telefone, Date nascimento){
//        
//    }
    
    public Cliente(Integer codigo, String nome, String telefone, Date nascimento){
        this.codigo = codigo;
        this.nome = nome;
        this.telefone = telefone;
        this.nascimento = nascimento;
    }
    
    public Cliente(){}
    
    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }


    
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
    
    
    
    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    
    
    
    public Date getNascimento() {
        return nascimento;
    }

    public void setNascimento(Date nascimento) {
        this.nascimento = nascimento;
    }
    
    private int codigo;
    
    private String nome;
    
    private String telefone;
    
    private Date nascimento;
    
}
