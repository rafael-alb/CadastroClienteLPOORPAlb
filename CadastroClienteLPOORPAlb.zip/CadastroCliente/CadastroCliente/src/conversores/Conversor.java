/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conversores;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author Stefano
 */
public class Conversor {
    
    public static Date StringParaData(String valor)
    {
        try
        {
               SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MM/yyyy");
               Date nascimento = sdf1.parse(valor);
               return nascimento;
        }
        catch(Exception e)
        {
            return null;
        }
    }
}
